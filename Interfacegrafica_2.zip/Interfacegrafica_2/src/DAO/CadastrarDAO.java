package DAO;

import DTO.CadastrarDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CadastrarDAO {

    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    ArrayList<CadastrarDTO> lista = new ArrayList<>();

    public void cadastrarUsuarios(CadastrarDTO objcadastrardto) {
        String sql = "insert into alunos (nomes_usuario, cursos_usuario, enderecos_usuario)values (?,?,?)";

        conn = new ConexaoDAO().conecta();

        try {

            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objcadastrardto.getNomes_usuario());
            pstm.setString(2, objcadastrardto.getCursos_usuario());
            pstm.setString(3, objcadastrardto.getEndereco_usuario());

            pstm.execute();
            pstm.close();

        } catch (Exception erro) {

            JOptionPane.showMessageDialog(null, "CadastrarDAO CadastrarUsuario" + erro);

        }
    }

    public ArrayList<CadastrarDTO> PesquisarUsuario() {
        String sql = "select * from alunos";
        conn = new ConexaoDAO().conecta();

        try {

            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();

            while (rs.next()) {
                CadastrarDTO objcadastrardto = new CadastrarDTO();
                objcadastrardto.setId_usuario(rs.getInt("id_usuario"));
                objcadastrardto.setNomes_usuario(rs.getString("nomes_usuario"));
                objcadastrardto.setCursos_usuario(rs.getString("cursos_usuario"));
                objcadastrardto.setEndereco_usuario(rs.getString("enderecos_usuario"));

                lista.add(objcadastrardto);
            }

        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, ("CadastrarDAO PesquisarUsuario") + erro);
        }
        return lista;
    }

    public void alterarUsuario(CadastrarDTO objcadastrardto) {
        String sql = "UPDATE alunos SET nomes_usuario = ?, cursos_usuario = ?, enderecos_usuario = ?" +  "where id_usuario = ?";
        conn = new ConexaoDAO().conecta();

        try {

            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objcadastrardto.getNomes_usuario());
            pstm.setString(2, objcadastrardto.getCursos_usuario());
            pstm.setString(3, objcadastrardto.getEndereco_usuario());
            pstm.setInt(4, objcadastrardto.getId_usuario());

            pstm.execute();
            pstm.close();

        } catch (Exception erro) {

            JOptionPane.showMessageDialog(null, "CadastrarDAO alterarUsuario" + erro);

        }
    }

    public void excluirUsuario(CadastrarDTO objcadastrardto) {

        String sql = "delete from alunos where id_usuario = ? ";

        conn = new ConexaoDAO().conecta();

        try {

            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, objcadastrardto.getId_usuario());

            pstm.execute();
            pstm.close();

        } catch (Exception erro) {

            JOptionPane.showMessageDialog(null, "cadastrarDAO excluirUsuario" + erro);

        }

    }

}
