package DTO;

public class CadastrarDTO {

private String nomes_usuario, cursos_usuario, enderecos_usuario;
private int id_usuario;


    /**
     * @return the nomes_usuario
     */
    public String getNomes_usuario() {
        return nomes_usuario;
    }

    /**
     * @param nomes_usuario the nomes_usuario to set
     */
    public void setNomes_usuario(String nomes_usuario) {
        this.nomes_usuario = nomes_usuario;
    }

    /**
     * @return the cursos_usuario
     */
    public String getCursos_usuario() {
        return cursos_usuario;
    }

    /**
     * @param cursos_usuario the cursos_usuario to set
     */
    public void setCursos_usuario(String cursos_usuario) {
        this.cursos_usuario = cursos_usuario;
    }

    /**
     * @return the endereco_usuario
     */
    public String getEndereco_usuario() {
        return enderecos_usuario;
    }

    /**
     * @param enderecos_usuario the enderecos_usuario to set
     */
    public void setEndereco_usuario(String enderecos_usuario) {
        this.enderecos_usuario = enderecos_usuario;
    }

    /**
     * @return the id_usuario
     */
    public int getId_usuario() {
        return id_usuario;
    }

    /**
     * @param id_usuario the id_usuario to set
     */
    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }
   
}


